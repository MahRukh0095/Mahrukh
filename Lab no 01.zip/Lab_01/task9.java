	import java.util.Scanner;
	public class task9{
	public static void main (String args []){
	Scanner calculator=new Scanner (System.in);

	System.out.println("Enter the first number : ");
	double num1=calculator.nextDouble();
	
	System.out.println("Enter the Second number : ");
	double num2=calculator.nextDouble();

	System.out.println("Enter the Symbol: +,_,*,/");
	char operation=calculator.next().charAt(0);

	switch(operation){
	case '+':
	System.out.println("Result is = "+ (num1+num2));
	break;
	case '-':
	System.out.println("Result is = "+ (num1-num2));
	break;	
	case '*':
	System.out.println("Result is = "+ (num1*num2));
	break;	
	case '/':
	System.out.println("Result is = "+ (num1/num2));
	break;	
	default:
	System.out.println("Sorry! Invalid choice");
	







}

	

}
}