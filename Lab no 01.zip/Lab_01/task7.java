	public class task7{
	public static void main (String args []){
	double pi=3.14;
	int r=4;
	int h=5;
	System.out.println("Volume is = "+ pi*(r*r)*h);
}
}