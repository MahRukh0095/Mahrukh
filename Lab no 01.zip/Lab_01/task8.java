	import java.util.Scanner;
	public class task8{
	public static void main (String args []){
	Scanner speed= new Scanner (System.in);
	
	System.out.println("Enter the Number in Mile :");
	double mile=speed.nextDouble();
	System.out.println("Total Kilometers ="+ (mile*1.6));
	
}
}