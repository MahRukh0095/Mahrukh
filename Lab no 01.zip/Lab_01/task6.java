	public class task6{
	public static void main (String args []){
	double dollar=3;
	System.out.println("Value in Rupees :"+ (dollar*288));
}
}