	public class task4{
	public static void main (String args []){
	System.out.println("Result is = "+(10+5)*(4-6)/4);
}
}