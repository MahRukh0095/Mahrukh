	public class task3{
	public static void main (String args []){
	String name ="MahNoor";
	int age= 18;
	double avg= 78.5;
	char Gender= 'F';
	Boolean foreigner= true;
	int id=0061;
	System.out.println("My name is "+name);
	System.out.println("My Age is "+age);
	System.out.println("My CGPA avg is "+avg);
	System.out.println("Gender is "+Gender);
	System.out.println("I'm foreigner "+foreigner);
	System.out.println("My Student id no: is "+id);
}
}