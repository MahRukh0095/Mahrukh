class Circle extends Shape {
    public void draw(){
       System.out.println("This is Circle.");


}



}