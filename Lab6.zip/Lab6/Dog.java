class Dog extands Animal{

public void makesound (){
System.out.println("Barking");


}
}