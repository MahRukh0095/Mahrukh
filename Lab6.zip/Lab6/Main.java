class Main{

public static void main(string [] args){
Dog d1= new Dog();
d1.makesound();

}
}