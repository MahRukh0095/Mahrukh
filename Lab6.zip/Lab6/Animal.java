class Animal{

String name;
int age;
public void makesound (){

}
}