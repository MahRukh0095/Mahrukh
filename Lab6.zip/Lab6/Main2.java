class Main{
    public static void main(String args[]){
     Car c1 = new Car ("Supra", 95, 2);
     c1.showDetails();
        System.out.println();
     Bike b1 = new Bike ("Electric Scoter", 70, "Opened");
       b1.showDetails();
}
  
}