class Rectangle extends Shape{
      public void draw(){

        System.out.println("This is Rectangle");
}
   
}