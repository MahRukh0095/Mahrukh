class Shape{
       public void draw(){
             System.out.println("Draw a Shape: ");
}
  
}