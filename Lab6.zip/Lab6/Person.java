//task2

class Person{
String name;
int age;
Person(String name,int age){
	this.name=name;
	this.age=age;
}
    void Displayinfo(){
 System.out.print("name"+name);
 System.out.print("age"+age);

}
}