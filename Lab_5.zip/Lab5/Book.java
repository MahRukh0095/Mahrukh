class Book{
String Title;
String Author;
boolean isAvailable=true;

void borrowBook(){
if(Title==isAvailable){
System.out.println("The book is borrowed.");
}
else{
System.out.println("Sorry book is already borrowed.");
}
}
void returnBook(){
}
void BookDetail(){
}
public static void main(String [] args){
Book b1=new Book


} 

}