class Employee{
String name;
String empID;
int Salary;

Employee(String name, String empID, int salary){
this.name=name;
this.empID=empID;
this.Salary=Salary;

}
public void IncreaseSalary(int amount){
Salary+=amount;

}
public double CalculateSalary(){
return Salary*12;

}

public void Displayinfo(){
System.out.println("Employee Name: "+name);
System.out.println("Employee ID:   "+empID);
System.out.println("Salary:        "+Salary);

}

public static void main(String args[]){

Employee e1=new Employee("MahRukh","95",2000);

e1.IncreaseSalary(2000);
e1.Displayinfo();
System.out.println("anual Salary " +e1. CalculateSalary());

}
}



