import java.util.Scanner;
public class Task3{
public static viod main(String[]args){
Scanner scanner = new Scanner(System.in);

String[] strs = new string [5];
for(int i=0; i<5; i++){
	System.out.println("Enter the String" +(i+1) +":");
	String strs = scanner.nextLine();
}
for(int i=0; i<5; i++){
	System.out.println("Uppercase String"+(i+1)+ strs [i].toUppercase());
	
	
}
}
}