import java.util.Scanner;
public class Empty{
public static void main(String[]args){
Scanner scanner = new Scanner(System.in);

System.out.println("Enter a String :");
String str = scanner.nextLine();
if (str.isEmpty()){
	System.out.println("string is Empty");
}	
 
else {
System.out.println("string is Not Empty");	
}
	

	
	
}

}