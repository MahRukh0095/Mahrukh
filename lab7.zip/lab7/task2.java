import java.util.Scanner;

public class task2{
public static void main(String[]args){
Scanner scanner = new Scanner(System.in);

System.out.println("Enter a String");
String str = scanner.nextLine();
int index = str.indexOf('a');
if (index != -1){
System.out.println("index of 'a' :" +index);	
}
else {
	System.out.println(-1);
	
	
}

}

}