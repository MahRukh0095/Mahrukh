
public class circle{
double radius;
String color;

void calculateArea(){
double Area=(Math.PI*radius*radius);
System.out.println("The calculaed area" +Area);
}
public static void main(String [] args){
circle green_circle= new circle();
circle red_circle= new circle();
green_circle.color="Green";
green_circle.radius=3.3;

red_circle.color="red";
red_circle.radius=4.4;

System.out.println(red_circle.radius);
System.out.println(green_circle.radius);

green_circle.calculateArea();
red_circle.calculateArea();


}
}