

import java.util.Scanner;

public class task5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        int rows = 5, cols = 5; 
        boolean[][] seats = new boolean[rows][cols]; 

        int choice;
        do {
            
            System.out.println("\nTheatre Seat Reservation System");
            System.out.println("1. Display available seats");
            System.out.println("2. Reserve a seat");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            
            switch (choice) {
                case 1:
              
                    System.out.println("Available seats (false = available, true = reserved):");
                    for (int i = 0; i < rows; i++) {
                        for (int j = 0; j < cols; j++) {
                            System.out.print(seats[i][j] + " ");
                        }
                        System.out.println();
                    }
                    break;

                case 2:
                    
                    System.out.print("Enter row number (0 to " + (rows - 1) + "): ");
                    int row = scanner.nextInt();
                    System.out.print("Enter column number (0 to " + (cols - 1) + "): ");
                    int col = scanner.nextInt();

                    if (row >= 0 && row < rows && col >= 0 && col < cols) {
                        if (!seats[row][col]) {
                            seats[row][col] = true;
                            System.out.println("Seat successfully reserved!");
                        } else {
                            System.out.println("Seat is already reserved. Please choose another seat.");
                        }
                    } else {
                       
                        System.out.println("Invalid row or column number. Please try again.");
                    }
                    break;

                case 3:
                   
                    System.out.println("Exiting the system. Thank you!");
                    break;

                default:
                
                    System.out.println("Invalid choice! Please enter a number between 1 and 3.");
            }
        } while (choice != 3);

        scanner.close();
    }
}

