class task2{
public static void main(String [] args){

for(int i=1; i<=15; i++){

 if (i %3==0){
System.out.println("fizz");
continue;
}
else if (i %5==0){
System.out.println("Buzz");
continue;}
else if (i % 3==0 && i%5==0){
System.out.println("fizzBuzz");
continue;
}
else 
{
System.out.println(i);
}

}

}
}
