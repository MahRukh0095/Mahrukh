class task3{
public static void main(String [] args){
int num=0;
int[]num1 ={1,1,2,2,3,3,4,4,5,5};
int[]num2=new int[num1.length];
for (int i=0; i<num1.length; i++){
if (num1[i]>num){
num=num1[i];
}
else{
num=0;
}
num2[i]=num+num2[i];
System.out.println(num2[i]);
}
}
}