class Duck implements flyable ,swimable{
	
	public void fly(){
		System.out.println("Duck fly");

		public void swim(){
			System.out.println("Duck swim");
		}
	}
}