class Main3{
	
public static void main (String [] args){
	Rectangle r = new Rectangle;
	r.Rectangle;

	System.out.println(r.area(2,4));

}
}