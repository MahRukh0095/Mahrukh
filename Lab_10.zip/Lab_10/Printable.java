interface Printable{
	void print();
}