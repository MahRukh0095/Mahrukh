interface swimable{
	void swim();
}