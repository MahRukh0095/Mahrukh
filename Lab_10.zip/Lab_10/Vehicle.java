interface Vehicle{
	void start();
	void stop();

	
}