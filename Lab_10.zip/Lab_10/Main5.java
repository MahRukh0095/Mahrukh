public class Main5 {
    public static void main(String[] args) {
        FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("Ayaan", 1, 50000.0);
        PartTimeEmployee partTimeEmployee = new PartTimeEmployee("Ayaan", 2, 200.0, 100);

        double fullTimeSalary = fullTimeEmployee.calculateSalary();
        System.out.println("Full-time employee salary: " + fullTimeSalary);
        fullTimeEmployee.payTax(fullTimeSalary);

        double partTimeSalary = partTimeEmployee.calculateSalary();
        System.out.println("Part-time employee salary: " + partTimeSalary);
        partTimeEmployee.payTax(partTimeSalary);
    }
}