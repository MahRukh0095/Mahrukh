abstract class Shape{
	abstract void area();
}  