class Cat extends Animal{
	void makeSound(){
		System.out.println("Meow Meow"); 
	}

}