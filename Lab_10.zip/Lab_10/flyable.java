interface flyable{
	void fly();
}