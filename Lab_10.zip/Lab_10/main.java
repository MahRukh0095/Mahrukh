class Main{

public static void main(String [] args){
	Dog d = new Dog();
	Cat c = new Cat();
	d.eat();
	d.makeSound();
	c.eat();
	c.makeSound();
	
}
}

