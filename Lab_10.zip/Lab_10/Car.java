class Car implements Vehicle {
	public void start(){
		System.out.println("start"); 
	}
	public void stop(){
	System.out.println("stop"); 	
	}

}