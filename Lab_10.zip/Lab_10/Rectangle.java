abstract class Rectangle extends Shape implements Printable{
	public void print(){
		System.out.println("Rectangle Area:");

	}
	public double area (int w , int l){
		return w*l;
	}

}