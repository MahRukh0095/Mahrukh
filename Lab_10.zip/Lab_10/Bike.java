class Bike implements Vehicle {
	public void start(){
		System.out.println("Start");

	}

	public void stop(){
		System.out.println("stop");
	}
}