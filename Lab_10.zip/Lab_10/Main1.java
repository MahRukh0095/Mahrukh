class Main{
	public static void main (String [] args){
		Car c = new Car();
		Bike b = new Bike();
		c.Start();
		c.Stop();
		b.Start();
		b.Stop();
	}
}