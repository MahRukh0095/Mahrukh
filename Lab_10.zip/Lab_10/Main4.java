class Main4{
	public ststic void main (String [] args){

		Duck d = new Duck;
		d.flyable();
		d.swimable();
	}
}